package com.example.whatismyfinalgrade;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText et1;
    private EditText et2;
    private double ag = 0;
    private double eg = 0;
    private TextView sv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.tf1);
        et2 = findViewById(R.id.tf2);
        sv = findViewById(R.id.showV);


    }

    public void calClick(View view) {

        if (et1.getText()!= null && et2.getText() != null) {
            ag = Double.parseDouble(et1.getText().toString());
            eg = Double.parseDouble(et2.getText().toString());
        }

        double fg = (ag + eg) / 2;
        sv.setText("Your final grade is " + fg);
    }

    public void clearClick(View view) {
        sv.setText("Final Grade");
        et1.setText("");
        et2.setText("");
    }
}
