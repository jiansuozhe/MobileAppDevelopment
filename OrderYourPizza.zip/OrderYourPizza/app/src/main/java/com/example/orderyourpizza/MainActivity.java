package com.example.orderyourpizza;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private CheckBox cb1;
    private CheckBox cb2;
    private RadioGroup rg;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;
    private TextView showV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb1 = findViewById(R.id.cb1);
        cb2 = findViewById(R.id.cb2);
        rg = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        showV = findViewById(R.id.showV);
    }

    public void orderClick(View view) {
        String ty = "";
        String si = "";
        if (rg.getCheckedRadioButtonId() != -1) {
            if (cb1.isChecked()) {
                ty += "cheese ";
            }

            if (cb2.isChecked()) {
                ty += "pepperoni";
            }

            if (rb1.isChecked()) {
                si += "small ";
            } else if (rb2.isChecked()) {
                si += "medium ";
            } else {
                si += "large ";
            }

            showV.setText("You ordered a " + si + ty);
        }
    }
}
