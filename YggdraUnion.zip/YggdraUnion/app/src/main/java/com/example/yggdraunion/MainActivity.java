package com.example.yggdraunion;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv1;
    ImageView img;
    TextView tv2;
    Button btn;
    Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Intent intent = new Intent(this, SecondActivity.class);
        final Intent intent2 = new Intent(this, ThirdActivity.class);


       SQLiteDatabase db = openOrCreateDatabase("yggdra", MODE_PRIVATE, null);
       db.execSQL("drop table if exists characters");
       db.execSQL("create table characters(" +
               "id int not null primary key," +
               "name varchar(20)," +
               "age int," +
               "class varchar(10)," +
               "intro varchar(50))");
       db.execSQL("insert into characters values(0, 'Yggdra', 17, 'King', 'King of Fantasinia and Emporer of Bronquian. Little Brave')");
       db.execSQL("insert into characters values(1, 'Milanor', 17, 'Thief', '666 Tool People just seems to be powerful')");
       db.execSQL("insert into characters values(2, 'Elena', 16, 'Assassin', 'Kind and Brave girl. She knows what she should do')");
       db.execSQL("insert into characters values(3, 'Rosary', 19, 'Witch', 'Leader of White Rose Domain. Confident (positive and negative)')");
       db.execSQL("insert into characters values(4, 'Gulcasa', 20, 'Dragon', 'Previous Emporer of Bronquian. The only beneficial news about him after his birth was his death')");




        tv1 = findViewById(R.id.tv1);



       img = findViewById(R.id.imageView);

        img.setPadding(2, 1 ,2 ,1);


        tv2 = findViewById(R.id.tv2);
        tv2.setText("'If I just fall down on the ground like this, their sacrifice will be nothing'\n" +
                "'Please reclaim the contract, my princess'\n" +
                "'I must stop them...Just before I died'\n" +
                "'Do you think you always have justice? Under the identity of that toy'\n" +
                "'Farewell'");


        btn = findViewById(R.id.btn);
        btn.setText("Characters");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(intent);
            }
        });


        btn2 = findViewById(R.id.btn2);
        btn2.setText("Cards");
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(intent2);
            }
        });



    }

}
