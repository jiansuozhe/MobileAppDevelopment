package com.example.yggdraunion;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        SQLiteDatabase db = openOrCreateDatabase("yggdra", MODE_PRIVATE, null);

        LinearLayout layout = findViewById(R.id.activity_second);

        TextView tv1 = new TextView(this);
        tv1.setText("Characters");
        layout.addView(tv1);

        TextView console = new TextView(this);
        layout.addView(console);

        String output = "\n";
        Cursor cr = db.rawQuery("select * from characters", null);
        if (cr.moveToFirst()){
            while (cr.moveToNext()){
                for (int i = 0; i < cr.getColumnCount(); i++){
                    output += cr.getString(i) + " ";
                }
                output += "\n";
            }
        }
        cr.close();
        console.setText(output);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Dialog");
        builder.setMessage("Welcome to Yggdra Union");
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
