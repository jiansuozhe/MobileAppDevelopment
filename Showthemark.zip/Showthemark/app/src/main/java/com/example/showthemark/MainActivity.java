package com.example.showthemark;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    Button button;
    EditText et1;
    EditText et2;
    TextView tv1;
    TextView tv2;

    private String name = "no name";
    private int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
    }

    public void btnClick(View view) {
        if (et1.getText().toString().equals("") || et2.getText().toString().equals("")){
            Toast.makeText(this,"Please enter your name/ID", Toast.LENGTH_SHORT).show();
        }
        else {
            name = et1.getText().toString();
            id = Integer.parseInt(et2.getText().toString());
            Scanner scan = new Scanner(getResources().openRawResource(R.raw.exammarks));
            HashMap<String, String> students = new HashMap<String, String>();
            HashMap<String, String> studentMarks = new HashMap<String, String>();
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] parts = line.split(" ");
                students.put(parts[0], parts[1]);
                studentMarks.put(parts[0], parts[2]);
            }
            boolean nameMatched = false;
            for (String key : students.keySet()) {
                if (name.equals(key)) {
                    if (id == Integer.parseInt(students.get(key))) {
                        Intent intent = new Intent(this, Main2Activity.class);
                        intent.putExtra("name", name);
                        intent.putExtra("mark", Integer.parseInt(studentMarks.get(name)));
                        startActivity(intent);
                        //tv1.setText("Hello" + name);
                       // tv2.setText("Your midterm exam mark is " + Integer.parseInt(studentMarks.get(name)));
                    } else {
                        Toast.makeText(this, "Wrong student ID", Toast.LENGTH_SHORT).show();
                    }
                    nameMatched = true;
                }
            }
            if (nameMatched == false) {
                Toast.makeText(this, "Student name does not exist", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
