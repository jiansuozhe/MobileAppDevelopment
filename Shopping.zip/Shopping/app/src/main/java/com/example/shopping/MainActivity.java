package com.example.shopping;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private double yggdra = 10.50;
    private double slay = 3.50;
    private double tw3 = 20.00;
    private double nt10 = 19.50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout layout = findViewById(R.id.activity_main);
        View inflatedView;

        inflatedView = getLayoutInflater().inflate(R.layout.game, null);
        ImageView iv1 = inflatedView.findViewById(R.id.icon);
        iv1.setImageResource(R.drawable.yggdra);
        TextView tv1 = inflatedView.findViewById(R.id.tv);
        tv1.setText("Price: $" + yggdra);
        final EditText et1 = inflatedView.findViewById(R.id.et);
        et1.setId(R.id.et1);
        layout.addView(inflatedView);

        inflatedView = getLayoutInflater().inflate(R.layout.game, null);
        ImageView iv2 = inflatedView.findViewById(R.id.icon);
        iv2.setImageResource(R.drawable.slay);
        TextView tv2 = inflatedView.findViewById(R.id.tv);
        tv2.setText("Price: $" + slay);
        final EditText et2 = inflatedView.findViewById(R.id.et);
        et2.setId(R.id.et2);
        layout.addView(inflatedView);

        inflatedView = getLayoutInflater().inflate(R.layout.game, null);
        ImageView iv3 = inflatedView.findViewById(R.id.icon);
        iv3.setImageResource(R.drawable.tw3);
        TextView tv3 = inflatedView.findViewById(R.id.tv);
        tv3.setText("Price: $" + tw3);
        final EditText et3 = inflatedView.findViewById(R.id.et);
        et3.setId(R.id.et3);
        layout.addView(inflatedView);

        inflatedView = getLayoutInflater().inflate(R.layout.game, null);
        ImageView iv4 = inflatedView.findViewById(R.id.icon);
        iv4.setImageResource(R.drawable.nt10);
        TextView tv4 = inflatedView.findViewById(R.id.tv);
        tv4.setText("Price: $" + nt10);
        final EditText et4 = inflatedView.findViewById(R.id.et);
        et4.setId(R.id.et4);
        layout.addView(inflatedView);

        Button btn = new Button(this);
        btn.setPadding(2,2,2,2);
        btn.setText("CHECKOUT");
        layout.addView(btn);

        final TextView tv = new TextView(this);
        layout.addView(tv);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double total = yggdra * Integer.parseInt(et1.getText().toString()) + slay * Integer.parseInt(et2.getText().toString()) + tw3 * Integer.parseInt(et3.getText().toString()) + nt10 * Integer.parseInt(et4.getText().toString());
                tv.setText("Total is $" + total);
            }
        });
    }
}
